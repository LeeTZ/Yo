# Yo
Yo is a user-friendly programming language for movie production. We offer the fastest and most efficient non-linear video editting. Users can produce from varieties of sources sush as images or existing video clips and apply system or user-defined functions to perform seamless video editting such as clip construction, duration adjustment, subtitle burning. In this light, Yo's objective is to facilitate editing on videos and less human effort needs to be involved.

## Build
make


## Features



## Future improvement



